(function() {
	var app = {};

	app.getConfig = function() {
		return JSON.parse(localStorage.getItem('si_config'));
	}

	//--------------------------------------------------------- Symbols --------------------------------------------------------//

	app.getCommonGridSymbol = function() {
		var symbol = new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
			new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
				new esri.Color([56, 59, 110, 0.7]), 2), new esri.Color([0, 0, 0, 0]));
		return symbol;
	}

	app.getCommonGridTextSymbol = function(txt) {
		var symbol = new esri.symbol.TextSymbol(txt);
		symbol.setKerning(false);
		symbol.setColor(new esri.Color([69, 69, 245, 1]));
		symbol.setHaloColor(new esri.Color([255, 255, 255, 0.6]));
		symbol.setHaloSize(2);
		var font = new esri.symbol.Font();
		font.setSize("8pt");
		font.setFamily('微软雅黑');
		font.setWeight(esri.symbol.Font.WEIGHT_BOLDER);
		symbol.setFont(font);
		return symbol;
	}

	app.getPictureSymbol = function(url, w, h, ox, oy) {
		var symbol = new esri.symbol.PictureMarkerSymbol(url, w, h);
		symbol.setOffset(ox, oy);
		return symbol;
	}

	app.getSolidLineSymbol = function(ragba, width) {
		var symbol = new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,
			new esri.Color(ragba),
			width
		);
		return symbol;
	}

	app.getSolidFillSymbol = function(frgba, lrgba, lw, fstyle, lstyle) {
		if(!fstyle) fstyle = esri.symbol.SimpleFillSymbol.STYLE_SOLID;
		if(!lstyle) lstyle = esri.symbol.SimpleLineSymbol.STYLE_SOLID;
		var symbol = new esri.symbol.SimpleFillSymbol(fstyle,
			new esri.symbol.SimpleLineSymbol(lstyle,
				new esri.Color(lrgba), lw), new esri.Color(frgba));
		return symbol;
	}

	//------------------------------------------------------ Tool Function -----------------------------------------------------------//
	app.zoomTo = function(map, feature) {
		var showExtent = feature.geometry.getExtent();
		map.setExtent(showExtent.expand(1.5), true);
	}
	app.zoomTos = function(map, features, graphicsUtils) {
		var showExtent = graphicsUtils.graphicsExtent(features);

		////////////////////////////////////////////////
		//showExtent.spatialReference.wkid = 4490;
		//showExtent.spatialReference.latestWkid = 4490;
		////////////////////////////////////////////////

		map.setExtent(showExtent.expand(1), true);
	}

	app.easyQuery = function(org,
		url,
		where,
		geometry,
		returnGeometry,
		resultCallback,
		errorCallback,
		token) {
		var param = new esri.tasks.Query();
		param.geometry = geometry;
		param.outFields = ['*'];
		param.returnGeometry = returnGeometry;

		if(org) {
			var orgType = org.type;
			var orgCode = org.code;

			switch(orgType) {
				case "1": //市
					{
						break;
					}
				case "2": //区
					{
						param.where = "QBM = '" + orgCode + "'";
						break;
					}
				case "3": //街
					{
						param.where = "JBM = '" + orgCode + "'";
						break;
					}
				case "4": //社区
					{
						param.where = "SQBM = '" + orgCode + "'";
						break;
					}
				case "5": //网格
					{
						param.where = "WGBM = '" + orgCode + "'";
						break;
					}
				default:
					break;
			}
		} else {
			param.where = where;
		}

		var task = new esri.tasks.QueryTask(url);
		task.showBusyCursor = true;
		task.requestTimeout = 60;
		task.execute(param, queryResult, queryFault);

		function queryResult(result) {
			resultCallback(result, token);
		}

		function queryFault(error) {
			errorCallback(error, token);
		}
	}

	app.renderGrids = function(features, layer, tlayer, level) {

		if(features && features.length > 0 && layer) {

			$.each(features, function(i, f) {
				f.symbol = app.getCommonGridSymbol();
				layer.add(f);
				if(tlayer) {
					var att = f.attributes;
					var geo = f.geometry.getExtent().getCenter();
					var txt = att.SSSQ + att.WGQC;
					var sym = app.getCommonGridTextSymbol(txt);
					var t = new esri.Graphic(geo, sym, {});
					tlayer.add(t);
				}
			});

			var map = layer.getMap();

			if(tlayer) {
				var _level = map.getLevel();
				tlayer.setVisibility(_level >= level);
				map.on('extent-change', function(evt) {
					var _level = map.getLevel();
					tlayer.setVisibility(_level >= level);
				});
			}

			app.zoomTos(map, features, graphicsUtils);
		}
	}

	app.substringContent = function(content, len) {
		var result = content.length > len ? content.substr(0, len) + '...' : content;
		return result;
	}

	app.post = function(url, data, contentType, dataType, result, fault) { 
		if(!arguments[2]) {
			contentType = "application/json";
		}
		if(!arguments[3]) {
			dataType = "json";
		}
		$.ajax({
			type: "post",
			dataType: dataType,
			contentType: contentType,
			url: url,
			data: data,
			async: true,
			success: result,
			error: fault
		});
	}

	app.get = function(url, contentType, result, fault) {
		if(!arguments[2]) {
			contentType = "application/json";
		}
		$.ajax({
			type: "get",
			contentType: contentType,
			url: url,
			async: true,
			success: result,
			error: fault
		});
	}

	app.toast = function(msg, time, shade, dom) {
		if(!time) time = 1000;
		if(dom) {
			return dom.layer.msg(msg, {
				time: time * 1000,
				shade: shade ? [0.6, '#393D49'] : null
			});
		} else {
			return layer.msg(msg, {
				time: time * 1000,
				shade: shade ? [0.6, '#393D49'] : null
			});
		}
	}

	app.close = function(tid, dom) {
		if(dom) {
			dom.layer.close(tid);
		} else {
			layer.close(tid);
		}
	}

	window.$app = app;
})();