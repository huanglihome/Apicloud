(function() {
	var cfg = JSON.parse(localStorage.getItem('si_config'));
	document.write("<link rel='stylesheet' href='" + cfg.api.arcgis.css + "'>");
	document.write("<script language='javascript' src='" + cfg.api.arcgis.js + "'></script>");
})();