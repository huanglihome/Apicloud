(function() {

	var $ = function() {
		if ('undefined' != typeof(config)) {
			setConfig(config);
		} else {
			console.log("错误：未引入config.js");
		}
	}

	var setConfig = function(c) {
		if (c) {
			localStorage.setItem('si_config', JSON.stringify(c));
		}
	}

	var getConfig = function() {
		return JSON.parse(localStorage.getItem('si_config'));
	}

	$();
	
})();