(function() {
	var utils = {};

	utils.uuid = function() {
		var s = [];
		var hexDigits = "0123456789abcdef";
		for (var i = 0; i < 36; i++) {
			s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
		}
		s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
		s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
		s[8] = s[13] = s[18] = s[23] = "-";
		var uuid = s.join("");
		return uuid;
	}

	utils.getParams = function() {
		var q = location.search.substr(1);
		var qs = q.split("&");
		if (qs) {
			var p = {};
			for (var i = 0; i < qs.length; i++) {
				var QueryName = qs[i].substring(0, qs[i].indexOf("="));
				var QueryValue = qs[i].substring(qs[i].indexOf("=") + 1);
				p[QueryName] = QueryValue;
			}
			return p;
		}
		return null;
	}

	utils.setCookie = function(name, value) {
		var Days = 30;
		var exp = new Date();
		exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
		document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
	}

	utils.getCookie = function(name) {
		var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
		if (arr = document.cookie.match(reg))
			return unescape(arr[2]);
		else
			return null;
	}

	utils.setStorage = function(name, value) {
		if (name && value) {
			localStorage.setItem(name, value);
		}
	}

	utils.getStorage = function(name) {
		if (name) {
			return localStorage.getItem(name);
		}
	}

	utils.createElement = function(name) {
		return document.createElement(name);
	};

	utils.createTextNode = function(txt) {
		return document.createTextNode(txt);
	};

	utils.filterField = function(key) {
		var reg = new RegExp('^[^\\u4e00-\\u9fff\\s]+$');
		return reg.test(key);
	}

	utils.bubbleSort = function(source) {
		var len = source.length;
		for (var i = 0; i < len; i++) {
			for (var j = len - 1; j > i; j--) {
				if (source[j] < source[j - 1]) {
					var tmp = source[j];
					source[j] = source[j - 1];
					source[j - 1] = tmp;
				}
			}
		}
	}

	utils.bubbleSort2 = function(source, key) {
		var len = source.length;
		for (var i = 0; i < len; i++) {
			for (var j = len - 1; j > i; j--) {
				if (source[j][key] < source[j - 1][key]) {
					var tmp = source[j];
					source[j] = source[j - 1];
					source[j - 1] = tmp;
				}
			}
		}
	}

	/**
	 * <p>
	 * 将Object对象转换为Array对象。
	 * </p>
	 * 
	 * @param node 任意值。
	 * 
	 * @return Array 数组。
	 * */
	utils.objectToArray = function(node) {
		var array = [];

		if (node instanceof Array)
			array = node;
		else
			array.push(node);

		return array;
	}

	utils.substringContent = function(content, len) {
		var result = content.length > len ? content.substr(0, len) + '...' : content;
		return result;
	}

	utils.trim = function(str) { //删除左右两端的空格
		return str.replace(/(^\s*)|(\s*$)/g, "");　　
	}　　
	utils.ltrim = function(str) { //删除左边的空格
		return str.replace(/(^\s*)/g, "");　　
	}　　
	utils.rtrim = function(str) { //删除右边的空格
		return str.replace(/(\s*$)/g, "");　　
	}

	/**
	 * <p> 保留有效数字 Retain Effective Digits</p>
	 * @param num 需要保留有效位数的数据，
	 * @param yxws 有效位数
	 * 
	 * @return Number
	 */
	utils.retainEffectiveDigits = function(num, yxws) {
		var n = Math.pow(10, yxws);
		return Math.round(num * n) / n;
	}

	window.$utils = utils;
})();