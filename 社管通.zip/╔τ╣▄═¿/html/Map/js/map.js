var config = $app.getConfig();
var map = null;
var tilelayer = null;
var graphicsUtils = null;
var orglayer = null;
var gridtxtlayer = null;
var houseLayer = null;
var houses = null;
var preg;
var preg2;
var defaultFeatures;
var historyPointLayer;
var historyPoints;
var marklayer;
var ismark = false;
var isSelected = false;
var submitPoint;
var deletePoint;

$(document).ready(function() {

	require(["esri/map",
		"esri/geometry/geometryEngine",
		"esri/layers/ArcGISTiledMapServiceLayer",
		"esri/layers/ArcGISDynamicMapServiceLayer",
		"esri/geometry/Extent",
		"esri/tasks/QueryTask",
		"esri/tasks/query",
		"esri/graphicsUtils",
		"esri/layers/GraphicsLayer",
		"esri/symbols/SimpleMarkerSymbol",
		"esri/symbols/SimpleFillSymbol",
		"esri/symbols/SimpleLineSymbol",
		"esri/Color",
		"esri/toolbars/draw",
		"tdlib/measure",
		"esri/tasks/GeometryService",
		"esri/tasks/LengthsParameters",
		"esri/tasks/AreasAndLengthsParameters",
		"esri/tasks/query",
		"esri/tasks/QueryTask",
		"esri/tasks/IdentifyTask",
		"esri/tasks/IdentifyParameters",
		"esri/geometry/Point",
		"esri/graphic"
	], function(Map, geometryEngine, ArcGISTiledMapServiceLayer, ArcGISDynamicMapServiceLayer, Extent, QueryTask, Query, graphicsUtils, GraphicsLayer, SimpleMarkerSymbol, SimpleFillSymbol, SimpleLineSymbol, Color, Draw, measure, Query, QueryTask, IdentifyTask, IdentifyParameters, Point, Graphic) {
		map = new Map("map", {
			logo: false
		});
		var base_url = config.mapservices[0].base_url;
		var child_url = config.mapservices[0].map2d;
		var tile_url = base_url + child_url;
		tilelayer = new ArcGISTiledMapServiceLayer(tile_url);
		map.addLayer(tilelayer);
		orglayer = new GraphicsLayer();
		map.addLayer(orglayer);
		houseLayer = new GraphicsLayer();
		map.addLayer(houseLayer);
		gridtxtlayer = new GraphicsLayer();
		map.addLayer(gridtxtlayer);
		historyPointLayer = new GraphicsLayer();
		map.addLayer(historyPointLayer);
		marklayer = new GraphicsLayer();
		map.addLayer(marklayer);
		map.on('load', function() {
			var cs = config.customSetting;
			var mp = new esri.geometry.Point(cs.x, cs.y);
			map.centerAndZoom(mp, cs.l);

			var wg_url = config.mapservices[1].base_url + config.mapservices[1].wg_url;
			initGrids(map, orglayer, wg_url, gridtxtlayer);
			queryHouse();
			queryHistoryPoint();
		});
		map.on('click', function(evt) {
			console.log(evt.mapPoint);
			mark(evt.mapPoint);
		});

		this.graphicsUtils = graphicsUtils;

		//html document
		$("#btn-reset").click(function() {
			reset();
		});

		$("#btn-mark").click(function() {
			if(!ismark) {
				$("#div-control").fadeIn('fast');
			} else {
				$("#div-control").fadeOut('fast');
				marklayer.clear();
			}
			ismark = !ismark;
		});

		$("#btn-submit").click(function() {
			if(submitPoint) {
				//ajax.....
				//submit point
				layer.msg('你确定要提交吗？', {
					time: 0, //不自动关闭
					btn: ['确定', '取消'],
					shade: [0.6, '#393D49'],
					yes: function(index) {
						layer.close(index);

						var tid = $app.toast('正在处理提交操作...', 10, true, null);

						var p = submitPoint.geometry;
						var u = config.appservices[0].base_url + config.appservices[0].LouDongPointAdd;
						var d = {};
						d.x = p.x;
						d.y = p.y;
						
						var wgbm = '';
						if(defaultFeatures) {
							$.each(defaultFeatures, function(i, f) {
								if(f.geometry.contains(p)) {
									wgbm = f.attributes.WGBM;
									return;
								}
							});
						}
						d.deptcode = wgbm;
						$app.post(u, JSON.stringify(d), null, null, result, fault);

						function result(rr) {
							$app.close(tid);

							var info = rr.result;
							if(info == '000000') {
								$app.toast('提交成功...', 1.5, true, null);
								var geo = submitPoint.geometry;
								var sym = get_point_wcj_unselected_symbol();
								var att = {};
								att.FWDBM = rr.buildingcode;
								att.WGBM = wgbm;
								att.SYMBOL_UNSELECTED = get_point_wcj_unselected_symbol();
								att.SYMBOL_SELECTED = get_point_wcj_selected_symbol();
								var g = new esri.Graphic(geo, sym, att);
								historyPointLayer.add(g);

								marklayer.remove(submitPoint);
								submitPoint = null;
							} else {
								if(!rr.msg) {
									rr.msg = '业务数据查询错误';
								}
								$app.toast(rr.msg, 3, true, null);
								console.log(rr.msg);
							}
						}

						function fault(e) {
							$app.close(tid);
							$app.toast('提交失败...', 1.5, true, null);
							console.log(e);
							marklayer.remove(submitPoint);
							submitPoint = null;
						}

					}
				});

			}
		});

		$("#btn-delete").click(function() {
			if(deletePoint) {
				//ajax.....
				//delete point

				layer.msg('你确定要删除吗？', {
					time: 0, //不自动关闭
					btn: ['确定', '取消'],
					shade: [0.6, '#393D49'],
					yes: function(index) {
						layer.close(index);

						var tid = $app.toast('正在处理删除操作...', 10, true, null);

						var fwdbm = deletePoint.attributes.FWDBM;
						var u = config.appservices[0].base_url + config.appservices[0].LouDongPointDelete;
						var d = {};
						d.buildingcode = fwdbm;

						$app.post(u, JSON.stringify(d), null, null, result, fault);

						function result(rr) {
							$app.close(tid);

							var info = rr.result;
							if(info == '000000') {
								$app.toast('删除成功...', 1.5, true, null);

								historyPointLayer.remove(deletePoint);
								deletePoint = null;
							} else {
								if(!rr.msg) {
									rr.msg = '业务数据查询错误';
								}
								$app.toast(rr.msg, 3, true, null);
								console.log(rr.msg);
							}
						}

						function fault(e) {
							$app.close(tid);
							$app.toast('删除失败...', 1.5, true, null);
							console.log(e);
						}

					}
				});
			}
		});
	});

	//------------------------------------------------------------ 初始化网格 --------------------------------------------------------------//
	var initGrids = function(map, layer, url, tlayer) {
		var tid = $app.toast('地图正在初始化...', 20, true, null);
		var orgcode = parent.orgcode;
		var org = {};
		org.code = orgcode;
		if(orgcode.length == 12) {
			org.type = '4';
		}
		if(orgcode.length == 15) {
			org.type = '5';
		}
		$app.easyQuery(org, url, '', null, true, resultCallback, errorCallback);

		function resultCallback(result, token) {
			var features = result.features;
			var cc = config.customSetting.PRO_HouseCollection;
			var showLevel = cc.textShowLevel;
			$app.renderGrids(features, layer, tlayer, showLevel);
			$app.close(tid);

			defaultFeatures = features;
		}

		function errorCallback(error, token) {
			console.log(error);
			$app.close(tid);
		}
	}

	//------------------------------------------------------------ 初始化房屋 --------------------------------------------------------------//
	function queryHouse() {
		var tid = $app.toast('业务数据加载中...', 10, true, null);

		//1 执行房屋业务库查询
		var u = config.appservices[0].base_url + config.appservices[0].LouDongGetStatusList;
		$app.post(u, null, null, null, result, fault);

		function result(rr) {
			$app.close(tid);

			var datas = null;
			var info = rr.result;
			if(info == '000000') {
				datas = rr.data;

				// 2 执行房屋空间库查询
				tid = $app.toast('房屋数据加载中...', 10, true, null);

				var houseurl = config.mapservices[1].base_url + config.mapservices[1].house_url;
				var where = '';
				var orgcode = parent.orgcode;
				if(orgcode.length == 12) {
					where = "SQBM='" + orgcode + "'";
				}
				if(orgcode.length == 15) {
					where = "WGBM='" + orgcode + "'";
				}
				var queryTask = new esri.tasks.QueryTask(houseurl);
				var query = new esri.tasks.Query();
				query.returnGeometry = true;
				query.outFields = ["*"];
				query.where = where;
				queryTask.execute(query, showResults);

				function showResults(results) {
					$app.close(tid);
					houses = results.features;
					var resultItems = [];
					var resultCount = results.features.length;
					for(var i = 0; i < resultCount; i++) {
						var f = results.features[i];
						//未采集
						f.symbol = get_wcj_unselected_symbol();
						f.attributes.SYMBOL_UNSELECTED = get_wcj_unselected_symbol();
						f.attributes.SYMBOL_SELECTED = get_wcj_selected_symbol();

						for(var k = 0; k < datas.length; k++) {
							var d = datas[k];
							if(d.buildingcode == f.attributes.FWDBM) {
								//if(d.datatype == '1') { //已采集
								f.symbol = get_ycj_unselected_symbol();
								f.attributes.SYMBOL_UNSELECTED = get_ycj_unselected_symbol();
								f.attributes.SYMBOL_SELECTED = get_ycj_selected_symbol();
								//}
							}
						}
						houseLayer.add(f);
					}
					var clicker = houseLayer.on("click", graphicClick);
					//clicker.remove();
				}

			} else {
				if(!rr.msg) {
					rr.msg = '业务数据查询错误';
				}
				$app.toast(rr.msg, 3, true, null);
				console.log(rr.msg);
			}
		}

		function fault(e) {
			$app.close(tid);
			console.log(e);
		}
	}

	//----------------------------------------------------------------初始化查询历史点---------------------------------------------------------------//
	var pointData = [
		{ "x": "112.14629216205701", "y": "32.038228591374015", "FWDBM": "1121462923203822890000001" },
		{ "x": "112.14632309505009", "y": "32.03828331897714", "FWDBM": "1121463233203828390000002" },
		{ "x": "112.1461660506237", "y": "32.037793150009946", "FWDBM": "1121461663203779390000003" }
	];

	function queryHistoryPoint() {
		historyPoints = [];

		var u = config.appservices[0].base_url + config.appservices[0].LouDongPointGetList;
		$app.post(u, null, null, null, result, fault);

		function result(rr) {
			var datas = null;
			var info = rr.result;
			if(info == '000000') {
				datas = rr.data;

				var i = 0;
				var len = datas.length;
				for(; i < len; i++) {
					var d = datas[i];
					var x = Number(d.x);
					var y = Number(d.y);
					var sp = new esri.SpatialReference(4490);
					var geo = new esri.geometry.Point(x, y, sp);

					var sym = null;
					var att = {};
					att.FWDBM = d.buildingcode;
					att.WGBM = d.deptcode;
					
					if(d.datatype == '1') { //已采集
						sym = get_point_ycj_unselected_symbol();
						att.SYMBOL_UNSELECTED = get_point_ycj_unselected_symbol();
						att.SYMBOL_SELECTED = get_point_ycj_selected_symbol();
					} else { //未采集
						sym = get_point_wcj_unselected_symbol();
						att.SYMBOL_UNSELECTED = get_point_wcj_unselected_symbol();
						att.SYMBOL_SELECTED = get_point_wcj_selected_symbol();
					}

					var f = new esri.Graphic(geo, sym, att);
					historyPointLayer.add(f);

					historyPoints.push(f);
				}
				var clicker = historyPointLayer.on("click", graphicClick);
				//clicker.remove();
			} else {
				if(!rr.msg) {
					rr.msg = '业务数据查询错误';
				}
				$app.toast(rr.msg, 3, true, null);
				console.log(rr.msg);
			}
		}

		function fault(e) {
			console.log(e);
		}
	}

	function graphicClick(e) {
		isSelected = true;
		var g = e.graphic;

		var x = 0;
		var y = 0;
		if(g.geometry.type == 'point') {
			deletePoint = g;
			x = g.geometry.x;
			y = g.geometry.y;
		} else {
			x = g.geometry.getExtent().getCenter().x;
			y = g.geometry.getExtent().getCenter().y;
		}

		if(preg) {
			preg.symbol = preg.attributes.SYMBOL_UNSELECTED;
			preg.draw();
		}
		g.symbol = g.attributes.SYMBOL_SELECTED;
		g.draw();
		preg = g;
		var att = g.attributes;
		att.x = x;
		att.y = y;
		//var fwbm = att.FWDBM;
		//var wgbm = att.WGBM;
		parent.call(att);
	}

});

var locate = function(fwdbm) {
	if(preg2) {
		var sym = preg2.attributes.SYMBOL_UNSELECTED;
		preg2.setSymbol(sym);
	}
	var i = 0;
	var len = houses.length;
	for(; i < len; i++) {
		var f = houses[i];
		var att = f.attributes;
		var code = att.FWDBM;
		if(code == fwdbm) {
			preg2 = f;
			f.setSymbol(get_highlight_symbol());
			$app.zoomTo(map, f);
			break;
		}
	}
	var j = 0;
	var len1 = historyPoints.length;
	for(; j < len1; j++) {
		var f = historyPoints[j];
		var att = f.attributes;
		var code = att.FWDBM;
		if(code == fwdbm) {
			preg2 = f;
			f.setSymbol(get_point_highlight_symbol());
			map.centerAt(f.geometry);
			break;
		}
	}
}

var mark = function(p) {
	if(isSelected) {
		isSelected = false;
		return;
	}

	if(ismark) {
		var inner = false;
		$.each(defaultFeatures, function(i, f) {
			if(f.geometry.contains(p)) {
				inner = true;
				return;
			}
		});
		if(!inner) {
			$app.toast('请在当前区域内操作.', 2, false);
			return;
		}

		marklayer.clear();
		var m = new esri.Graphic(p, get_temp_point_symbol(), {});
		marklayer.add(m);
		submitPoint = m;
	}
}

//复位
var reset = function() {
	if(defaultFeatures) {
		$app.zoomTos(map, defaultFeatures, graphicsUtils);
	}
}

var refreshHouse = function(fwdbm) {
	if(houses) {
		var i = 0;
		var len = houses.length;
		for(; i < len; i++) {
			var f = houses[i];
			var att = f.attributes;
			var code = att.FWDBM;
			if(code == fwdbm) {
				f.setSymbol(get_ycj_selected_symbol());
				break;
			}
		}
	}

	if(historyPoints) {
		var j = 0;
		var len1 = historyPoints.length;
		for(; j < len1; j++) {
			var f = historyPoints[j];
			var att = f.attributes;
			var code = att.FWDBM;
			if(code == fwdbm) {
				f.setSymbol(get_point_ycj_selected_symbol());
				break;
			}
		}
	}
}

///---------------------SYMBOLS

//点已采集未选中
function get_point_ycj_unselected_symbol() {
	return new esri.symbol.SimpleMarkerSymbol(esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
		10,   
		new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,   
			new esri.Color([0, 0, 255]), 1),   new esri.Color([0, 0, 255, 0.6])
	);
	//	var path = "M 100 100 L 300 100 L 200 300 z";
	//	var markerSymbol = new esri.symbol.SimpleMarkerSymbol();
	//          markerSymbol.setPath(path);
	//          markerSymbol.setColor(new esri.Color([0, 0, 255, 0.6]));
	//          markerSymbol.setOutline(null);
	//          markerSymbol.setSize(30);
	//	return markerSymbol;
}

//点已采集选中
function get_point_ycj_selected_symbol() {
	return new esri.symbol.SimpleMarkerSymbol(esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
		10,   
		new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,   
			new esri.Color([255, 0, 0]), 2),   new esri.Color([0, 0, 255, 0.6])
	);
}

//点未采集未选中
function get_point_wcj_unselected_symbol() {
	return new esri.symbol.SimpleMarkerSymbol(esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
		10,   
		new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,   
			new esri.Color([0, 0, 0]), 1), new esri.Color([0, 0, 0, 0.6])
	);
}

//点未采集选中
function get_point_wcj_selected_symbol() {
	return new esri.symbol.SimpleMarkerSymbol(esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
		10,   
		new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,   
			new esri.Color([255, 0, 0]), 2), new esri.Color([0, 0, 0, 0.6])
	);
}

//已采集未选中
function get_ycj_unselected_symbol() {
	return new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
		new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
			new esri.Color([0, 0, 255]), 1), new esri.Color([0, 0, 255, 0.25]));
}

//已采集选中
function get_ycj_selected_symbol() {
	return new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
		new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
			new esri.Color([255, 0, 0]), 2), new esri.Color([0, 0, 255, 0.25]));
}

//未采集未选中
function get_wcj_unselected_symbol() {
	return new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
		new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
			new esri.Color([0, 0, 0]), 1), new esri.Color([0, 0, 0, 0.25]));
}

//未采集选中
function get_wcj_selected_symbol() {
	return new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
		new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
			new esri.Color([255, 0, 0]), 2), new esri.Color([0, 0, 0, 0.25]));
}

//高亮显示
function get_highlight_symbol() {
	return new esri.symbol.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
		new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
			new esri.Color([255, 0, 0]), 2), new esri.Color([255, 0, 0, 0.5]));
}

//点高亮显示
function get_point_highlight_symbol() {
	return new esri.symbol.SimpleMarkerSymbol(esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
		10,   
		new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,   
			new esri.Color([255, 0, 0]), 2), new esri.Color([255, 0, 0, 0.5])
	);
}

//临时点
function get_temp_point_symbol() {
	return new esri.symbol.SimpleMarkerSymbol(esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
		10,   
		new esri.symbol.SimpleLineSymbol(
			esri.symbol.SimpleLineSymbol.STYLE_SOLID,   
			new esri.Color([0, 0, 0]), 2), new esri.Color([255, 0, 0, 1])
	);
}