var baseip = localStorage.getItem("dituip");
var mapip = localStorage.getItem("mapip");
console.log(baseip);
console.log(mapip);
var config = {
	"debug": "false",
	"mapservices": [{
		"base_url": mapip+":6080/arcgis/rest/services/",
		"map2d": "xiangyang/map2d/MapServer",
		"geometry": "Geometry/GeometryServer"
	}, {
		"base_url": mapip+":6080/arcgis/rest/services/",
		"wg_url": "xiangyang/gim_ahw/MapServer/1",
		"house_url": "xiangyang/gim_ahw/MapServer/0",
		//"address_url": "wuchang_gim/gim_ahw/MapServer/0",
		"geometry": "Utilities/Geometry/GeometryServer "
	}],
	"appservices": [{//接口的配置
		"base_url": baseip+":204/",
		"LouDongGetStatusList": "gim/LouDong/GetStatusList",
		"LouDongPointGetList":"gim/LouDongPoint/GetList",
		"LouDongPointAdd":"gim/LouDongPoint/Add",
		"LouDongPointDelete":"gim/LouDongPoint/Delete"
	}],
	"api": {
		"arcgis": {
			"version": "316",
			"css": mapip+":89/arcgis/js316/esri/css/esri.css",
			"js": mapip+":89/arcgis/js316/init.js"
		}
	},
	"customSetting": {
		"x": 114.31062577742394,
		"y": 30.55619854979865,
		"l": 8,
		"PRO_HouseCollection": {
			"textShowLevel": 8,
		}
	}
}
