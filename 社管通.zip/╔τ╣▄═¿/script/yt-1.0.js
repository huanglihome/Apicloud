
//                     r.                                      7DB3
//                     KBRH                                  7RM;sr
//                     BMBMBR                               JBBBJs E.
//                   uBBBRBRBRMB;                          :BBBD i.r
//                 BBMRMBMB1RBMBM.                         :7. 0FZRE.
//    UMW,         0MBBR.   BRBM,                         ;.L:.sLr;:i
//     HRBRBR2       .    EBR;                            7JGH7Ssr:i
//      BBMMBMZ         BMBBWUMRBRBW                      r;BS:OXLRBs
//     L;, ,,.        7BRMRBMBBERMBBR.                     ;7x,UMBMBB:
//              .MBZHRBMBBBR;   BRBBc                       :r7iBBBRU
// HBBMBRZi       MBMBr   MMO rBBBB
//   DMMBBMMX     OMBM   FBMBBMBMBB,
//      RBBE      :BBMBBMBMKi, .
//     MBM       EBRMRBBMBi;23:   BBR.
//     KMM        ::7MMM7  RBBB  BBBMv
//      :BMB        WMB   7BB:  .UWU
//        0BM     LMRL   ,RB                          LBBBBBx
//        BBM    BMM      EBMRBRBRMRBRMRM.       cBBBBBMMMMRs
//   FBBRBMBRMRBBMB:         i1U0BBBD2;           sBBBRMM7
//    BBBRSuZORRMRBBMMBMM1c                         MRS
//                   rSBRBMBBBRBMBBBBBMBBBRMRMRL  :BR     :x:
//                         ;xSBMBMBRMBBMBRBRJi.    BMMvWBBBBMB
//                                  .:,           ,BMBMBBM7
//                                            ;0BMMBBMB
//                                          LBRBBBBBBBRBS
//                                            ,. ;BM   rBBBv
//                                               BBB      MBBc
//                                              XBBi       ,BMMMr
//                                            cBBB2          KRBRBBMZ7
//                                          i1X:               :RBBRBBBBR

/*
 * yt.js---V1.0
 * 用于APiCloud的
 * by 逸天 QQ:980558532
 * 2016-08-04
 */
var httpurl='';//
var timestamp=new Date();
var zidian='';
(function (window) {
    var u = {};

    var DEBUG = true, RELEASE = false;//运行状态控制,DEBUG模式和RELEASE模式

    var _buildtype = DEBUG;

    //获取设备类型
    u.getDeviceModel = function(deviceModel){
        if(!deviceModel){
            return api.deviceModel;
        }else{
            return api.deviceModel.indexOf(deviceModel)!=-1?true:false;
        }
    }

    u.ready = function (callback) {
        if (typeof callback == 'function') {
            apiready = function () {
                callback();
            }
        }
    }

    u.openWin = function (winname, winurl, typeid, pageParam) {
        var animationtype = ["none", "push", "movein"];
        if (typeid) {
            api.openWin({
                name: winname,
                url: winurl + winname + '.html',
                animation: {
                    type: typeid?animationtype[typeid]:animationtype[0],
                    duration: 200
                },
                delay: 300,
                pageParam: pageParam,
                reload: true,
                softInputMode: 'pan'
            });
        }
    }

    u.openFrame = function (framename, frameurl, header, pageParam, footer) {
        u.fixStatusBar(header, function () {
            var y = header ? $(header).outerHeight() : 0;
            var footerH = footer ? $(footer).outerHeight() : 0;
            console.log(y);
            api.openFrame({
                name: framename,
                url: frameurl + framename + '.html',
                rect: {
                    x: 0,
                    y: y,
                    w: 'auto',
                    h: window.innerHeight - y - footerH
                },
                pageParam: pageParam ? pageParam : {},
                bounces: true
            });
        })
    }
    u.closeWin = function (param) {
        api.closeWin(param);
    }
    u.execScript = function (name, frameName,fn,callback) {
        var jsfun = 'funcGoto();';
        var param = {};
        param.name = name;
        if (frameName) { param.frameName = frameName; }
        param.script = fn;
        u.log(JSON.stringify(param));
        api.execScript(param);
        if (typeof callback == 'function') {
            callback();
        }
    }
    u.KeyBack = function(callback){
  		api.addEventListener({
  		    name: 'keyback'
  		}, function(ret, err) {
  		    if (typeof callback == 'function') {
              callback();
              }
  		});
  	}
    u.getNowTime = function () {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    var Hour = date.getHours();
    var Minu = date.getMinutes();
    var sec = date.getSeconds()
    if (month >= 1 && month <= 9) {
      month = "0" + month;
    }
    if (Hour >= 1 && Hour <= 9) {
      Hour = "0" + Hour;
    }
    if (Minu >= 1 && Minu <= 9) {
      Minu = "0" + Minu;
    }
    if (sec >= 1 && sec <= 9) {
      sec = "0" + sec;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
      + " " + Hour + seperator2 + Minu
      + seperator2 + sec;
    return currentdate;
  }
    u.ajax = function (url, method, param, callback, progress) {
        u.log('param:' + JSON.stringify(param));
        postnumber = $api.getStorage("postnumber") == null ? 204 : $api.getStorage("postnumber");
        var httpdurl = ($api.getStorage("ip") == null ? httpurl : "http://"+$api.getStorage("ip"))+":" + postnumber + url;
        u.log(httpdurl);
        api.ajax({
            url: httpdurl,
            method: method,
            dataType:'json',
            data: {
                values: param
            }
        }, function (ret, err) {
            api.hideProgress();
            if (ret) {
                //u.log('ret:' + JSON.stringify(ret));
                if (typeof callback == 'function') {
                    callback(ret);
                }
            } else {
                u.alert('网络请求错误');
                u.log('err:' + JSON.stringify(err));
            }
        });
    }

    u.setStatusBarStyle = function (callback, style) {
        api.setStatusBarStyle({ style: !style ? 'light' : style });
        if (typeof callback == 'function') {
            callback();
        }
    }
    u.setRefreshHeaderInfo = function (callback) {
        api.setRefreshHeaderInfo({
            bgColor: '#f4f4f4'
        }, function (ret, err) {
            if (typeof callback == 'function') {
                callback(ret, err);
            }
        });
    }
    u.refreshHeaderLoadDone = function (callback) {
        api.refreshHeaderLoadDone();
        if (typeof callback == 'function') {
            callback();
        }
    }
    u.alert = function (msg, title, callback) {
        api.alert({
            title: title || "温馨提示",
            msg: msg,
        }, function (ret, err) {
            if (typeof callback == 'function') {
                callback();
            }
        });
    }
    u.toast = function (msg, callback, locationid) {
        var location = ['top', 'middle', 'bottom'];
        api.toast({
            msg: msg,
            duration: 1000,
            location: location[locationid]||'bottom'
        });
        setTimeout(function () {
            if (typeof callback == 'function') {
                callback();
            }
        }, 1000);
    }
    u.fixStatusBar = function (el,callback) {
        $api.fixStatusBar($(el)[0]);
        if (typeof callback == 'function') {
            callback();
        }
    }
    u.getOptionByType = function(ty,callback){
      var htmlstr=[];
      var data ="";
              api.readFile({
                  path: 'fs://zidan.xml'
              }, function(ret, err) {
                  if (ret.status) {
                      data = JSON.parse(ret.data);
                      zidian = data;
                        //console.log(data);
                        ty.forEach(function(tyval,tyindex,tyarr){
                          var hl = "";
                            data.data.forEach(function(val,index,arr){
                              if(val.key == tyval.toUpperCase() && val.parentcode == ""){
                                 var selstr = "";
                                if(val.value == "号" || val.value == "栋"){
                                  selstr = "selected = 'selected'";
                                }
                                hl += "<option value='"+val.code+"' class='"+val.code+"' "+selstr+">"+val.value+"</option>";
                              }
                            })
                            htmlstr.push({"type":tyval,"str":hl});
                        })
                        if (typeof callback == 'function') {
                            callback(htmlstr);
                        }
                  } else {
                      alert(err.msg);
                  }
              });
    }

    u.getOptionByparentId = function(id,callback){
      var htmlstr="";
      var data ="";
              api.readFile({
                  path: 'fs://zidan.xml'
              }, function(ret, err) {
                  if (ret.status) {
                      data = JSON.parse(ret.data);
                      zidian = data;
                        //console.log(data);
                        data.data.forEach(function(val,index,arr){
                          if(val.parentcode == id){
                            htmlstr += "<option value='"+val.value+"' class='"+val.code+"' data-xyz='"+val.code+"'>"+val.value+"</option>";
                          }
                        })
                        if (typeof callback == 'function') {
                            callback(htmlstr);
                        }
                  } else {
                      alert(err.msg);
                  }
              });
    }

    u.getOptionByparentId2 = function(id,callback){
      var htmlstr="";
      var data ="";
              api.readFile({
                  path: 'fs://zidan.xml'
              }, function(ret, err) {
                  if (ret.status) {
                      data = JSON.parse(ret.data);
                      zidian = data;
                        //console.log(data);
                        data.data.forEach(function(val,index,arr){
                          if(val.parentcode == id){
                            htmlstr += "<option value='"+val.code+"' class='"+val.code+"' data-xyz='"+val.code+"'>"+val.value+"</option>";
                          }
                        })
                        if (typeof callback == 'function') {
                            callback(htmlstr);
                        }
                  } else {
                      alert(err.msg);
                  }
              });
    }

    u.tranJsonToarray = function(callback){
      api.readFile({
          path: 'fs://zidan.xml'
      }, function(ret, err) {
          if (ret.status) {
              data = JSON.parse(ret.data);
              zidian = data;
                //console.log(data);
                var obj = {};
                data.data.forEach(function(val,index,arr){
                    if(obj[val.key]==null){
                      obj[val.key] = {};
                      obj[val.key][val.code] = val.value;
                    }else{
                      obj[val.key][val.code] = val.value;
                    }
                })
                //console.log(JSON.stringify(obj));
                if (typeof callback == 'function') {
                    callback(obj);
                }
          } else {
              alert(err.msg);
          }
      });
    }
    u.log = function (msg, tag) {
        if (_buildtype) {
            console.log((tag ? tag + ':' : "") + msg);
        }
    }
     u.scrolltobottom = function(px,callback){
    	api.addEventListener({
		    name:'scrolltobottom',
		    extra:{
		        threshold:px            //设置距离底部多少距离时触发，默认值为0，数字类型
		    }
		}, function(ret, err){
            if (typeof callback == 'function') {
                callback();
            }
		});
    }

    function getBuildType() {
        return _buildtype == DEBUG ? "DEBUG:" : "RELEASE:";
    }
    window.yt = u;
})(window);

Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
